// API Circuit Breaker & Exponential Backoff Module
class CircuitBreaker {
  constructor(maxFailures = 3, resetTimeoutMs = 30000) {
    this.maxFailures = maxFailures;
    this.resetTimeoutMs = resetTimeoutMs;
    this.failures = 0;
    this.state = 'CLOSED';
    this.nextAttempt = Date.now();
  }
  async execute(fn) {
    if (this.state === 'OPEN') {
      if (Date.now() > this.nextAttempt) {
        this.state = 'HALF_OPEN';
      } else {
        throw new Error('CIRCUIT_OPEN: Temporarily blocking API calls');
      }
    }
    try {
      const res = await fn();
      this.failures = 0;
      this.state = 'CLOSED';
      return res;
    } catch (err) {
      this.failures++;
      if (this.failures >= this.maxFailures) {
        this.state = 'OPEN';
        this.nextAttempt = Date.now() + this.resetTimeoutMs;
      }
      throw err;
    }
  }
}
module.exports = { CircuitBreaker };
