# Commercial License & Terms (PRD-API-005)

1. Core License grants single-user / single-business deployment rights.
2. Commercial License grants multi-client agency deployment rights for client projects.
