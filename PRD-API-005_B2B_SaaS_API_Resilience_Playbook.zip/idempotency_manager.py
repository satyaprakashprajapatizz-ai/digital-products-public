# Atomic Idempotency Key Manager
import sqlite3
import hashlib

def is_duplicate(conn, idempotency_key):
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS idempotency (key TEXT PRIMARY KEY, created_at TEXT)")
    cursor.execute("SELECT key FROM idempotency WHERE key = ?", (idempotency_key,))
    return cursor.fetchone() is not None

def record_key(conn, idempotency_key, now_iso):
    cursor = conn.cursor()
    cursor.execute("INSERT INTO idempotency (key, created_at) VALUES (?, ?)", (idempotency_key, now_iso))
    conn.commit()
