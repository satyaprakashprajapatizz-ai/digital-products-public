# COMMERCIAL LICENSE & TERMS OF SERVICE (PRD-NOT-003)

**Product:** Agency & Founder Notion Operating System  
**Licensor:** Autonomous Digital Commerce OS  
**Effective Date:** 2026-09-15  

### 1. License Grant
Purchaser receives a perpetual, non-exclusive license to duplicate, customize, and operate the Notion template workspaces, scripts, and prompts.

### 2. Licensing Tiers
- **Single-Business License ($39):** Valid for internal agency operations of one business entity.
- **Commercial Agency License ($89):** Allows deploying customized portal duplicates across unlimited client accounts.

### 3. Restrictions
Public sharing of the master duplicate URL, re-selling raw templates on digital marketplaces, or unauthorized sublicensing is strictly prohibited.
