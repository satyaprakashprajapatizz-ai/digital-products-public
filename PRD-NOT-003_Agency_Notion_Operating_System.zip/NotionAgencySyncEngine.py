#!/usr/bin/env python3
"""
Notion Agency Sync & Portal Provisioning Engine (PRD-NOT-003)
Zero-Cost Automation Utility for Agency Notion OS
"""
import json
import sys

def validate_schema(schema_file):
    with open(schema_file, 'r') as f:
        data = json.load(f)
    db_names = [d["name"] for d in data.get("databases", [])]
    required = ["CRM & Client Roster", "Projects & Retainers", "Sprint Tasks & Deliverables", "Standard Operating Procedures (SOP Vault)", "Invoices & Financial Tracking"]
    for req in required:
        assert req in db_names, f"Missing required database: {req}"
    return True, len(db_names)

def generate_client_portal_manifest(client_name, primary_email, projects):
    manifest = {
        "portal_name": f"Client Portal - {client_name}",
        "access_permission": "can_view_and_comment",
        "primary_email": primary_email,
        "shared_views": [
            {"view": "Active Milestones", "source": "Projects & Retainers", "filter": {"client": client_name}},
            {"view": "Deliverables Sign-Off", "source": "Sprint Tasks & Deliverables", "filter": {"client": client_name, "completed": True}},
            {"view": "Invoices & Receipts", "source": "Invoices & Financial Tracking", "filter": {"client": client_name}}
        ],
        "private_agency_views_hidden": True
    }
    return manifest

if __name__ == "__main__":
    print("=== NOTION AGENCY OS AUTOMATION HARNESS ===")
    valid, count = validate_schema("/working_dir/c_a77593e2be2343ba/autonomous_digital_commerce_os/catalog/PRD-NOT-003/Notion_Agency_OS_Master_Schema.json")
    print(f"Schema Validation: PASS ({count} core databases verified)")
    portal = generate_client_portal_manifest("Vanguard Media", "ops@vanguard.co", ["Q4 Brand Relaunch"])
    print(f"Sample Portal Provisioned: {portal['portal_name']} (Privacy Protected: {portal['private_agency_views_hidden']})")
