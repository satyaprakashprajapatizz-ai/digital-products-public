/**
 * ============================================================================
 * AGENCY CLIENT INTAKE & WEBHOOK ROUTER (V2.0 HARDENED)
 * Zero-Cost Serverless Webhook Processor with Idempotency & Deduplication
 * Operating Platform: Google Apps Script + Google Sheets
 * License: Commercial Single-Business / Agency License
 * ============================================================================
 */

function doPost(e) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(10000)) {
    return ContentService.createTextOutput(JSON.stringify({ 
      status: "error", 
      error_code: "LOCK_TIMEOUT",
      message: "Server busy. Please retry in a few seconds." 
    })).setMimeType(ContentService.MimeType.JSON);
  }

  try {
    const rawData = e.postData ? e.postData.contents : "{}";
    const payload = JSON.parse(rawData);
    
    // Strict input validation
    if (!payload.contact_email || !payload.contact_email.includes("@")) {
      return ContentService.createTextOutput(JSON.stringify({
        status: "rejected",
        error_code: "INVALID_EMAIL",
        message: "A valid contact_email is required."
      })).setMimeType(ContentService.MimeType.JSON);
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName("CUSTOMERS");
    if (!sheet) {
      sheet = ss.insertSheet("CUSTOMERS");
      sheet.appendRow(["Client ID", "Created At", "Company Name", "Contact Email", "Project Scope", "Budget", "Status", "Idempotency Key"]);
    }

    const cleanEmail = payload.contact_email.toLowerCase().trim();
    const data = sheet.getDataRange().getValues();
    
    // Idempotency / Duplicate Check
    for (let i = 1; i < data.length; i++) {
      const existingEmail = String(data[i][3] || "").toLowerCase().trim();
      if (existingEmail === cleanEmail) {
        return ContentService.createTextOutput(JSON.stringify({
          status: "idempotent_success",
          client_id: data[i][0],
          message: "Client record already exists. Updated existing session.",
          existing: true
        })).setMimeType(ContentService.MimeType.JSON);
      }
    }

    const clientId = "CLI-" + Utilities.getUuid().substring(0, 8).toUpperCase();
    const now = new Date().toISOString();
    const idempotencyKey = payload.idempotency_key || Utilities.getUuid();
    
    sheet.appendRow([
      clientId,
      now,
      payload.company_name || "Confidential Client",
      cleanEmail,
      payload.project_scope || "Standard Onboarding",
      payload.budget || "$0",
      "ONBOARDING_STAGED",
      idempotencyKey
    ]);

    return ContentService.createTextOutput(JSON.stringify({ 
      status: "success", 
      client_id: clientId, 
      timestamp: now,
      existing: false
    })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ 
      status: "error", 
      error_code: "EXECUTION_EXCEPTION",
      message: err.toString() 
    })).setMimeType(ContentService.MimeType.JSON);
  } finally {
    lock.releaseLock();
  }
}
