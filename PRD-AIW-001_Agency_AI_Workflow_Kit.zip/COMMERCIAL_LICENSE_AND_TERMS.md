# COMMERCIAL LICENSE & TERMS OF SERVICE (PRD-AIW-001)

**Product:** Agency AI Workflow & Client Onboarding Automation Kit  
**Licensor:** Autonomous Digital Commerce OS  
**Effective Date:** 2026-09-15  

### 1. License Grant
Purchaser receives a perpetual, non-exclusive license to utilize, customize, and deploy the workflow scripts, blueprints, and prompt vaults.

### 2. Tiers
- **Single-Business License ($29):** Permitted for internal operations of one legal agency entity.
- **Agency License ($79):** Permitted for deployment across unlimited client accounts managed by the purchasing agency.

### 3. Restrictions
Re-selling, distributing, or sublicensing the raw source files as an unbundled standalone digital product is strictly prohibited.
