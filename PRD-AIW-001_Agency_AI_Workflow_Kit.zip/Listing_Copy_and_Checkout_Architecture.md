# Marketplace Listing & Checkout Architecture (PRD-AIW-001)

## 1. Listing Metadata
- **Product Title:** Agency AI Workflow & Client Onboarding Automation Kit
- **Tagline:** Eliminate $150/mo Zapier bills. Turnkey n8n blueprints + Google Apps Script router for boutique agencies.
- **Category:** Business Automation / Developer Tools / Spreadsheets & Workflows
- **Keywords:** n8n workflow, agency onboarding, client intake automation, Zapier alternative, Google Apps Script CRM

## 2. Sales Page Copy
Tired of paying $150 to $300 every month for Zapier tasks just to onboard clients?

**The Agency AI Workflow & Onboarding Kit gives you a battle-tested, zero-fixed-cost automation engine.**

### What's Included:
1. **Ready-to-Import n8n Blueprint:** Full webhook-to-CRM pipeline with AI brief generation.
2. **Serverless Google Apps Script Router:** Zero external servers; handles client form data inside your Google Sheet.
3. **30 Master Agency Prompts:** AI templates for scope extraction, project milestones, and client updates.
4. **Step-by-Step PDF Playbook:** Complete SOP manual walking you through deployment in 10 minutes.

### Pricing:
- Core Kit: $29.00 (One-Time)
- Agency Multi-Seat License: $79.00 (One-Time)
