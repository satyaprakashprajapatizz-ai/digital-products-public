#!/usr/bin/env python3
"""
Solopreneur Runway & Cash-Flow Analytical Engine (PRD-FIN-002)
Zero-Cost Local / Cloud Financial Health Evaluator
"""
import sys

def calculate_runway(starting_cash, monthly_inflow, monthly_burn):
    net_burn = monthly_burn - monthly_inflow
    if net_burn <= 0:
        return "INFINITE_RUNWAY (CASH-FLOW POSITIVE)", net_burn, 999.0
    runway_months = starting_cash / net_burn
    return "NET_BURN_ACTIVE", net_burn, round(runway_months, 1)

def run_scenarios(starting_cash, base_inflow, base_burn):
    scenarios = {
        "Conservative (-20% Inflow, +10% Burn)": (base_inflow * 0.8, base_burn * 1.1),
        "Baseline (Current Pace)": (base_inflow, base_burn),
        "Optimistic (+20% Inflow, -5% Burn)": (base_inflow * 1.2, base_burn * 0.95)
    }
    results = {}
    for name, (inf, brn) in scenarios.items():
        status, net, rway = calculate_runway(starting_cash, inf, brn)
        results[name] = {"inflow": inf, "burn": brn, "net_monthly": -net, "runway_months": rway}
    return results

if __name__ == "__main__":
    print("=== SOLOPRENEUR RUNWAY EVALUATOR ===")
    res = run_scenarios(15000, 3500, 2050)
    for s_name, data in res.items():
        print(f"Scenario: {s_name}")
        print(f"  Monthly Inflow: ${data['inflow']:,.2f} | Monthly Burn: ${data['burn']:,.2f}")
        print(f"  Net Cash Flow: ${data['net_monthly']:,.2f} | Runway: {data['runway_months']} months")
        print()
