# COMMERCIAL LICENSE & TERMS OF SERVICE (PRD-FIN-002)

**Product:** Solopreneur Cash-Flow & P&L Forecasting Spreadsheet OS  
**Licensor:** Autonomous Digital Commerce OS  
**Effective Date:** 2026-09-15  

### 1. License Grant
Purchaser receives a perpetual, non-exclusive license to utilize, modify, and duplicate the spreadsheet models, scripts, and documentation.

### 2. Licensing Tiers
- **Single-Business License ($19):** For internal financial tracking of one solopreneur or business entity.
- **Commercial Agency License ($49):** For deployment across unlimited client accounts managed by the purchasing consultancy or bookkeeping firm.

### 3. Restrictions
Direct resale, public distribution, or unbundled repackaging of the raw source template files as a competing digital product is strictly prohibited.
