# Marketplace Listing & Checkout Architecture (PRD-FIN-002)

## 1. Listing Metadata
- **Product Title:** Solopreneur Cash-Flow & P&L Forecasting Spreadsheet OS (Excel & Google Sheets)
- **Tagline:** Stop overpaying $360/year for accounting software. Instant 12-month runway clarity, cash-flow forecasting, and tax set-aside calculations.
- **Category:** Business Finance / Spreadsheets & Templates / Financial Tools
- **Keywords:** cash flow spreadsheet, runway calculator, freelancer finances, solopreneur P&L template, Excel cash forecasting

## 2. Sales Page Copy
Are you constantly checking your bank account balance and wondering if you have enough cash for next month?

Most accounting software charges $30 to $90 every single month for complex bookkeeping features you don't even need.

**The Solopreneur Cash-Flow Spreadsheet OS gives you complete, forward-looking runway visibility for a one-time payment of $19.**

### What You Get:
1. **The 12-Month Proactive Forecast Engine:** Dynamic model tracking retainers, project billing, fixed costs, and personal draws.
2. **Instant Runway Dashboard:** Visual indicators showing exactly how many months of cash buffer you have.
3. **Automated Tax Reserve Calculator:** Automatically sets aside 25-30% of revenue so quarterly taxes never surprise you.
4. **20 Financial AI Prompts:** Ready-to-use copy for invoice reminders, rate increases, and expense audits.
5. **Step-by-Step PDF Playbook:** Executive guide taking you from setup to total financial clarity in 15 minutes.

### Pricing:
- Core Single-User License: $19.00 (One-Time)
- Commercial Agency License: $49.00 (One-Time)
