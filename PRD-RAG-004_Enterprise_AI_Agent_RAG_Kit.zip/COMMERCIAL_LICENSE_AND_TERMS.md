# Commercial License & Terms (PRD-RAG-004)

1. Core License grants single-user / single-business deployment rights.
2. Commercial License grants multi-client agency deployment rights for client projects.
3. Distribution of raw blueprint files as standalone templates is prohibited.
