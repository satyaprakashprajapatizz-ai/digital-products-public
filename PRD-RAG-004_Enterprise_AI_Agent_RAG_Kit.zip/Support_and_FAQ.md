# Support & FAQ: PRD-RAG-004

Q: Which vector databases are supported?
A: PGVector, Qdrant, Pinecone, and Chroma.

Q: Is n8n required?
A: No, Python scripts are included for standalone deployment.
