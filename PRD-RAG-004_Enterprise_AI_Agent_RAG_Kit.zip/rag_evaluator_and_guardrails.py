# RAG Context Retrieval & Zero-Hallucination Guardrail Evaluator
import json

def evaluate_retrieval(query, retrieved_chunks, answer):
    grounded = any(chunk.lower() in answer.lower() for chunk in retrieved_chunks)
    return {
        "query": query,
        "grounded": grounded,
        "score": 1.0 if grounded else 0.0,
        "status": "PASS" if grounded else "HALLUCINATION_RISK"
    }

if __name__ == "__main__":
    sample = evaluate_retrieval(
        "What is the system timeout?",
        ["The system timeout is set to 30000ms in SQLite config."],
        "The system timeout is 30000ms."
    )
    print("Evaluation Result:", json.dumps(sample, indent=2))
