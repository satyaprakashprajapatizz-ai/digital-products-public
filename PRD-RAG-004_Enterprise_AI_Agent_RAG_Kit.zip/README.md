# Enterprise AI Agent & Knowledge Base (RAG) Architecture Blueprint & Operations Kit

Welcome to the Enterprise AI Agent & Knowledge Base (RAG) Operations Kit (PRD-RAG-004).

## Contents
1. `PRD-RAG-004_Master_Specification.md` - Complete architectural blueprint and data flow schemas.
2. `Enterprise_AI_Agent_RAG_Architecture_Guide.pdf` - Step-by-step PDF implementation guide.
3. `n8n_RAG_Agent_Pipeline_Blueprint.json` - Production-ready n8n workflow for hybrid RAG search & LLM agent routing.
4. `vector_db_hybrid_search_config.json` - Configs for PGVector, Qdrant, and Pinecone chunking strategies.
5. `rag_evaluator_and_guardrails.py` - Runnable Python script to evaluate context retrieval accuracy and enforce zero-hallucination guardrails.
6. `COMMERCIAL_LICENSE_AND_TERMS.md` - Usage rights and licensing details.
7. `Support_and_FAQ.md` - FAQ and troubleshooting.

## Quickstart
1. Import `n8n_RAG_Agent_Pipeline_Blueprint.json` into your n8n instance.
2. Configure vector database credentials using `vector_db_hybrid_search_config.json`.
3. Run `python rag_evaluator_and_guardrails.py` to test context retrieval accuracy.

License: Commercial & Single-Seat Core
Support: support@ai-automation-studio.local
